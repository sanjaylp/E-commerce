import React from "react";

function Offer(){
    return(
        <div className="Offer">
        <marquee width="100%" direction="right" height="100px" speed="10">
 <h3>Flat 30% Offer for first order in month of july !!!!!</h3>
</marquee>
        </div>
    )
}export default Offer;