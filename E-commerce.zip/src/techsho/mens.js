import React from "react";


function Mens() {
  return (
    <div>
    <div className="cloths">


      <div className="container1">
        <div className="coloum">
        <a href="/Home"> <img src="ms.1.png"></img><br></br></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
      
        </div>
        <div className="coloum">
        <a href="/Home"><img src="ms.2.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
      
        </div>
        <div className="coloum">
        <a href="/Home"> <img src="ms.3.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
      


        </div>

      
        <div className="coloum">
        <a href="/Home"> <img src="m2.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home"> <img src="m3.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home"> <img src="m4.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home"> <img src="m5.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home"><img src="m6.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
         <a href="/Home"><img src="m7.png"></img></a> 
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home"> <img src="m8.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home"> <img src="m9.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home">   <img src="mp.1.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
      
        </div>
        <div className="coloum">
        <a href="/Home">  <img src="mp.2.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
      
        </div>
        <div className="coloum">
        <a href="/Home">    <img src="mp.3.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home">  <img src="mp4.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home"> <img src="mp5.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home">  <img src="mp6.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home">   <img src="mp7.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home">  <img src="mp8.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
        <div className="coloum">
        <a href="/Home">  <img src="mp9.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
       
        <div className="coloum">
        <a href="/Home">  <img src="mp.1.png"></img></a>
          <p>LEVIS</p>
          <p>Printed Slim Fit Shirt</p>
        </div>
       
        
      </div>
    </div>

    </div>
  )
}
export default Mens;

