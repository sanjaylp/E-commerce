import React from "react";
function Banner() {
return(
<div>
  
     <div class="bannerhead">
     
    <img src="banner.1.webp" ></img>
    <img  id="img2" src="finalbanner.webp" ></img>
    <img id="img3" src="finalimg1.png" ></img>
  
  </div>
  <div>
<marquee>
  <h1>
    Flat 30% offer for first order !!!!!!!
  </h1>
</marquee>

  </div>
  <div class="scroll-container2">
      
                  <video id="vid" controls autoPlay muted loop >
                      <source src="v2.mp4"  />
                  </video>
                  
                
              </div>
              
             
          </div>
)
}
export default Banner;